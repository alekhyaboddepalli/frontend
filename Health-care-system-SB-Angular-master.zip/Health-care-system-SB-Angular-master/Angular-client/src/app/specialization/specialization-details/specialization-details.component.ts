import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-specialization-details',
  templateUrl: './specialization-details.component.html',
  styleUrls: ['./specialization-details.component.css']
})
export class SpecializationDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
