export class Department{
    deptId:number;
    deptName: string;
}