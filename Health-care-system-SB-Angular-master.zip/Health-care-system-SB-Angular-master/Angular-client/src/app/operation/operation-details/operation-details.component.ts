import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-operation-details',
  templateUrl: './operation-details.component.html',
  styleUrls: ['./operation-details.component.css']
})
export class OperationDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
