import { DoctorPipe } from './doctor.pipe';

describe('DoctorPipe', () => {
  it('create an instance', () => {
    const pipe = new DoctorPipe();
    expect(pipe).toBeTruthy();
  });
});
