import { InsurancePipe } from './insurance.pipe';

describe('InsurancePipe', () => {
  it('create an instance', () => {
    const pipe = new InsurancePipe();
    expect(pipe).toBeTruthy();
  });
});
