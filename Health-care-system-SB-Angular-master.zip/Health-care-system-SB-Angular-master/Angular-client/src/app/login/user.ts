export class user{
    username: string;
    password: string;
}