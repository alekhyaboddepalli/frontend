package com.coforge.hms.model;

public enum ERole {
	ROLE_USER,
    ROLE_ADMIN
}
